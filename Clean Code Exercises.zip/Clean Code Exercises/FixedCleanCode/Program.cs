﻿using System;

class Program
{
    const int COMPARE_TO_NUMBER = 5;
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = GetValidatedNumber();

        DisplayNumberProperties(number);
    }

    static int GetValidatedNumber()
    {
        while (true)
        {
            if (int.TryParse(Console.ReadLine(), out int result))
            {
                return result;
            }

            Console.WriteLine("Invalid input. Please enter a valid integer.");
        }
    }

    static void DisplayNumberProperties(int number)
    {
        Console.WriteLine($"The number {number} is " + (IsEven(number) ? "Even" : "Odd"));

        if (number > COMPARE_TO_NUMBER)
        {
            Console.WriteLine(string.Format("It’s greater than {0}.", COMPARE_TO_NUMBER));
        }
        else if (number < COMPARE_TO_NUMBER)
        {
            Console.WriteLine(string.Format("It’s less than {0}.", COMPARE_TO_NUMBER));
        }
        else
        {
            Console.WriteLine(string.Format("It’s exactly {0}.", COMPARE_TO_NUMBER));
        }

        Console.WriteLine($"Double: {number * 2}, Triple: {number * 3}");

        if (number < 0)
        {
            Console.WriteLine("Warning: Negative number detected!");
        }
    }

    static bool IsEven(int num) => num % 2 == 0;
}