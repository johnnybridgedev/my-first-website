﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a number:");
        int x = Convert.ToInt32(Console.ReadLine());

        if (x > 5)
        {
            if (x % 2 == 0)
            {
                Console.WriteLine("Even number greater than 5");
            }
            else
            {
                Console.WriteLine("Odd number greater than 5");
            }
        }
        else
        {
            if (x < 5)
            {
                if (x % 2 == 0)
                {
                    Console.WriteLine("Even number less than 5");
                }
                else
                {
                    Console.WriteLine("Odd number less than 5");
                }
            }
            else
            {
                Console.WriteLine("It's 5");
            }
        }

        int y = x * 2; int z = x * 3;
        Console.WriteLine("Double: " + y);
        Console.WriteLine("Triple: " + z);

        if (x < 0)
        {
            Console.WriteLine("Negative number detected!");
            Console.WriteLine("Be careful!");
            Console.WriteLine("Warning issued.");
        }
    }
}
